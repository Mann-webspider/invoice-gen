import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import api from "@/lib/axios";

interface User {
  id: string;
  email: string;
  role: "admin" | "user";
  name: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  setUser: (user: User | null) => void;
  isAuthenticated: boolean;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const checkSession = async () => {
    try {
      const token = localStorage.getItem("authToken");
      if (token) {
        api.defaults.headers.common["Authorization"] = `Bearer ${token}`;
        const response = await api.get("/check-session");
        if (response.data) {
          setUser(response.data);
        }
      }
    } catch (error) {
      console.error("Session check failed:", error);
      localStorage.removeItem("authToken");
      delete api.defaults.headers.common["Authorization"];
    }
  };
  useEffect(() => {
    // Check for existing session
    const checkSession = async () => {
      try {
        const token = localStorage.getItem("authToken");
        if (token) {
          api.defaults.headers.common["Authorization"] = `Bearer ${token}`;
          const response = await api.get("/check-session");
          if (response.data) {
            setUser(response.data.user.sub.user);
          }
        }
      } catch (error) {
        console.error("Session check failed:", error);
        localStorage.removeItem("authToken");
        delete api.defaults.headers.common["Authorization"];
      }
    };

    checkSession();
  }, []);

  const login = async (email: string, password: string) => {
    try {
      console.log("Sending login request to:", api.defaults.baseURL + "/login");
      const response = await api.post("/login", { email, password });
      console.log("Login response:", response.data);
      
      if (response.data && response.data.token) {
        const { token, user } = response.data;
        localStorage.setItem("authToken", token);
        api.defaults.headers.common["Authorization"] = `Bearer ${token}`;
        setUser(user);
      } else {
        throw new Error("Login failed: No token received");
      }
    } catch (error: any) {
      console.error("Login error details:", {
        message: error.message,
        response: error.response?.data,
        status: error.response?.status
      });
      throw error;
    }
  };

  const logout = async () => {
    try {
      await api.post("/auth/logout");
    } catch (error) {
      console.error("Logout failed:", error);
    } finally {
      localStorage.removeItem("authToken");
      delete api.defaults.headers.common["Authorization"];
      setUser(null);
    }
  };

  const value = {
    user,
    login,
    logout,
    setUser,
    isAuthenticated: !!user,
    isAdmin: user?.role === "admin",
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}; 