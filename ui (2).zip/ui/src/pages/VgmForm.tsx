import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format } from "date-fns";
import { useForm } from "@/context/FormContext";
import api from "@/lib/axios";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import {generateInvoiceExcel} from '@/lib/excelGenerator'
import { AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
interface VgmFormProps {
  onBack: () => void;
  containerInfo?: {
    containerRows: any[];
    totalPalletCount: string;
  };
  invoiceHeader?: {
    invoiceNo: string;
    invoiceDate: Date;
    email: string;
    taxid: string;
    ieCode: string;
    panNo: string;
    gstinNo: string;
    stateCode: string;
    selectedExporter: string;
    companyAddress: string;
  };
}

interface ExporterWithImages {
  id: string;
  company_name: string;
  company_address: string;
  email: string;
  tax_id: string;
  ie_code: string;
  pan_number: string;
  gstin_number: string;
  state_code: string;
  authorized_name?: string;
  authorized_designation?: string;
  contact_number?: string;
  letterhead_top_image?: string;
  letterhead_bottom_image?: string;
  stamp_image?: string;
}

const VgmForm = ({ onBack, containerInfo, invoiceHeader }: VgmFormProps) => {
  // State for form data
  let { formData, setVGMData } = useForm();
  console.log(formData.annexure);
  let navigate = useNavigate();
  // State for shipper information
  const [selectedShipper, setSelectedShipper] = useState<ExporterWithImages | null>(null);
  const [letterheadTopImage, setLetterheadTopImage] = useState<string>("");
  const [letterheadBottomImage, setLetterheadBottomImage] = useState<string>("");
  const [stampImage, setStampImage] = useState<string>("");
  const [imagesLoaded, setImagesLoaded] = useState<boolean>(false);
  const [shipperRegistration, setShipperRegistration] = useState<string>("");
  const [shipperOfficial, setShipperOfficial] = useState<string>("");
  const [contactDetails, setContactDetails] = useState<string>("");
  const [weighingDate, setWeighingDate] = useState<string>(
    format(new Date(), "dd.MM.yyyy")
  );
  const [weighingTime, setWeighingTime] = useState<string>(
    format(new Date(), "HH:mm")
  );
  const [containerSize, setContainerSize] = useState<string>("20'");
  const [containerNumber, setContainerNumber] =
    useState<string>("AS PER ANNEXURE");
  const [weighBridgeNo, setWeighBridgeNo] = useState<string>("AS PER ANNEXURE");
  const [verifiedGrossMass, setVerifiedGrossMass] =
    useState<string>("method-1");
  const [unitOfMeasure, setUnitOfMeasure] = useState<string>("KG");
  const [weighingSlipNo, setWeighingSlipNo] =
    useState<string>("AS PER ANNEXURE");
  const [containerType, setContainerType] = useState<string>("NORMAL");
  const [hazardousClass, setHazardousClass] = useState<string>("NA");
  const [availableSuppliers, setAvailableSuppliers] = useState([]);
  // State for booking numbers and tare weights for each container
  const [bookingNumbers, setBookingNumbers] = useState<string[]>([]);
  const [tareWeights, setTareWeights] = useState<string[]>([]);

  async function getExporters() {
    let res = await api.get("/exporter");
    if (res.status !== 200) {
      return "error";
    }
    return res.data.data;
  }

  useEffect(() => {
    (async () => {
      try {
        const fetchedExporters = await getExporters();
        setAvailableSuppliers(fetchedExporters);
        console.log(fetchedExporters);
        
      } catch (error) {
        console.error("Failed to fetch suppliers:", error);
      }
    })();
  }, []);

  // create a function for getting images from api call and convert it into displayable format
  const getImageUrl = (id: string,type:string) => {
    if (!id) return "";
    let api =  `${import.meta.env.VITE_API_BASE_URL}/upload/${type}/${id}`
    
    return api;
  };
  const handleSupplierSelect = (value: string) => {
    const selectedSupplier = availableSuppliers.find(s => s.company_name === value);
    console.log("Selected supplier:", selectedSupplier);
    
    setSelectedShipper(selectedSupplier);
    
    // Check if the supplier has letterhead images
    if (selectedSupplier) {
      setImagesLoaded(false);
      
      // Set letterhead top image
      if (selectedSupplier.letterhead_top_image) {
        getImageUrl(selectedSupplier.id,"header")
        setLetterheadTopImage(getImageUrl(selectedSupplier.id,"header"));
        setImagesLoaded(true);
      } else {
        setLetterheadTopImage("");
      }
      
      // Set letterhead bottom image
      if (selectedSupplier.letterhead_bottom_image) {
        setLetterheadBottomImage(getImageUrl(selectedSupplier.id,"footer"));
        setImagesLoaded(true);
      } else {
        setLetterheadBottomImage("");
      }
      
      // Set stamp image
      if (selectedSupplier.stamp_image) {
        setStampImage(getImageUrl(selectedSupplier.id,"signature"));
      } else {
        setStampImage("");
      }
    } else {
      setLetterheadTopImage("");
      setLetterheadBottomImage("");
      setStampImage("");
      setImagesLoaded(false);
    }
  };
  // Predefined shipper options
  const shippers: { [key: string]: any } = {
    "ZERIC CERAMICA": {
      registration: "I. E. Code #: AA********",
      official: "ROHIT KACHADIYA",
      contact: "**12******",
    },
    "DEMO VITRIFIED PVT LTD": {
      registration: "I. E. Code #: BB********",
      official: "JOHN DOE",
      contact: "**13******",
    },
  };

  useEffect(() => {
    // Initialize with containerInfo data if available
    if (containerInfo?.containerRows) {
      // Default shipper to the one from invoice header
      if (invoiceHeader?.selectedExporter) {
        handleShipperSelect(invoiceHeader.selectedExporter);
      }

      // Initialize booking numbers and tare weights arrays
      const newBookingNumbers = containerInfo.containerRows.map(
        () => "EI*********"
      );
      const newTareWeights = containerInfo.containerRows.map(() => "2180");

      setBookingNumbers(newBookingNumbers);
      setTareWeights(newTareWeights);
    }
  }, [containerInfo, invoiceHeader]);

  const handleShipperSelect = (shipper: string) => {
    setSelectedShipper(shipper);

    // Auto-fill related fields based on selected shipper
    if (shipper in shippers) {
      const shipperInfo = shippers[shipper];
      setShipperRegistration(shipperInfo.registration);
      setShipperOfficial(shipperInfo.official);
      setContactDetails(shipperInfo.contact);
    }
  };

  const handleBookingNumberChange = (index: number, value: string) => {
    const newBookingNumbers = [...bookingNumbers];
    newBookingNumbers[index] = value;
    setBookingNumbers(newBookingNumbers);
  };

  const handleTareWeightChange = (index: number, value: string) => {
    const newTareWeights = [...tareWeights];
    newTareWeights[index] = value;
    setTareWeights(newTareWeights);
  };

  // const handleSubmit = () => {
  //   console.log(formData);

  //   // Here you can add logic to submit the form
  //   alert("Form submitted successfully!");
  // };

   const handleSubmit =async ()=>{
      try {
        




        // logic for saving invoice in backend api POST /api/invoice from formData.invoice with api
        console.log(formData);
        
        const response = await api.post("/invoice",formData)
        console.log("Invoice saved successfully:", response.data);
        toast.success("Invoice saved successfully");
       if(response.status === 201){
          let invoice = await api.get(`/invoice/${response.data.id}`);
          let excelData = invoice.data;
          
          console.log("Excel data:", excelData);
          
          
          await generateInvoiceExcel(excelData)
          // navigate to packaging list page
          // navigate('/annexure');
        }
  
       
      } catch (error) {
        console.error("Error saving invoice:", error);
        toast.error("Error saving invoice");
      }
    }

  // Calculate total VGM (Gross Weight + Tare Weight)
  const calculateTotalVGM = (grossWeight: string, tareWeight: string) => {
    const gross = parseFloat(grossWeight || "0");
    const tare = parseFloat(tareWeight || "0");
    return (gross + tare).toFixed(2);
  };

  // Set the VGM data in the form context
  useEffect(() => {
    setVGMData({
      shipper_name: selectedShipper?.company_name || "",
      ie_code: selectedShipper?.ie_code || "",
      authorized_name: selectedShipper?.authorized_name || "",
      authorized_contact: selectedShipper?.contact_number || "",
      container_number: containerNumber,
      container_size: containerSize,
      permissible_weight: "AS PER ANNEXURE",
      weighbridge_registration: weighBridgeNo,
      verified_gross_mass: verifiedGrossMass,
      unit_of_measurement: unitOfMeasure,
      dt_weighing: `${weighingDate} ${weighingTime}`,
      weighing_slip_no: weighingSlipNo,
      type: containerType,
      IMDG_class: hazardousClass,
      containers:
        containerInfo?.containerRows.map((row, index) => ({
          booking_no: bookingNumbers[index] || "",
          container_no: row.containerNo,
          gross_weight: row.grossWeight || "0.00",
          tare_weight: tareWeights[index] || "0",
          total_vgm: calculateTotalVGM(
            row.grossWeight || "0",
            tareWeights[index] || "0"
          ),
        })) || [],
    });
  }, [
    selectedShipper,
    shipperRegistration,
    shipperOfficial,
    contactDetails,
    containerNumber,
    containerSize,
    weighBridgeNo,
    verifiedGrossMass,
    unitOfMeasure,
    weighingSlipNo,
    containerType,
    hazardousClass,
    tareWeights,
  ]);
  // Render the form

  return (
    <div className="space-y-6">
      {/* Letterhead Top Image */}
      {letterheadTopImage ? (
        <div className="w-full flex justify-center">
          <img 
            src={letterheadTopImage} 
            alt="Letterhead Top" 
            className="w-full object-contain max-h-40"
          />
        </div>
      ) : selectedShipper ? (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Missing Letterhead</AlertTitle>
          <AlertDescription>
            Please add the letterhead top image for {selectedShipper.company_name} through the Admin panel.
          </AlertDescription>
        </Alert>
      ) : null}
      
      {/* Header */}
      <div className="bg-white p-6 shadow-sm border rounded-lg">
        <h1 className="text-3xl font-bold text-center mb-2">VGM</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold">
            INFORMATION ABOUT VERIFIED GROSS MASS OF CONTAINER
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Form fields in numbered format */}
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t pt-4">
              <div className="space-y-2">
                <Label className="font-medium">1. Name of the shipper</Label>
                <Select
                  value={selectedShipper?.company_name || ""}
                  onValueChange={(value) =>
                    handleSupplierSelect(value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select supplier" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableSuppliers.map((s) => (
                      <SelectItem key={s.id} value={s.company_name}>
                        {s.company_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <div className="font-medium text-red-600">
                  {selectedShipper?.company_name || "Select a shipper"}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t pt-4">
              <div className="space-y-2">
                <Label className="font-medium">
                  2. Shipper Registration /License no.( IEC No/CIN No)**
                </Label>
                <Input
                  value={selectedShipper?.ie_code || ""}
                  readOnly
                  className="bg-gray-50"
                />
              </div>
              <div className="space-y-2">
                <div className="font-medium">{selectedShipper?.ie_code || ""}</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t pt-4">
              <div className="space-y-2">
                <Label className="font-medium">
                  3. Name and designation of official of the shipper authorized
                </Label>
                <Input
                  value={selectedShipper?.authorized_name || ""}
                  readOnly
                  className="bg-gray-50"
                />
              </div>
              <div className="space-y-2">
                <div className="font-medium">{selectedShipper?.authorized_name || ""}</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t pt-4">
              <div className="space-y-2">
                <Label className="font-medium">
                  4. 24 x 7 contact details of authorised official of shipper
                </Label>
                <Input value={selectedShipper?.contact_number || ""} readOnly className="bg-gray-50" />
              </div>
              <div className="space-y-2">
                <div className="font-medium">{selectedShipper?.contact_number || ""}</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t pt-4">
              <div className="space-y-2">
                <Label className="font-medium">5. Container No.</Label>
                <Input
                  value={containerNumber}
                  onChange={(e) => setContainerNumber(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <div className="font-medium">{containerNumber}</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t pt-4">
              <div className="space-y-2">
                <Label className="font-medium">
                  6. Container Size ( TEU/FEU/other)
                </Label>
                <Select value={containerSize} onValueChange={setContainerSize}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="20'">20'</SelectItem>
                    <SelectItem value="40'">40'</SelectItem>
                    <SelectItem value="40' HC">40' HC</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <div className="font-medium">{containerSize}</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t pt-4">
              <div className="space-y-2">
                <Label className="font-medium">
                  7. Maximum permissible weight of container as per the CSC
                  plate
                </Label>
                <Input value="AS PER ANNEXURE" onChange={(e) => {}} />
              </div>
              <div className="space-y-2">
                <div className="font-medium">AS PER ANNEXURE</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t pt-4">
              <div className="space-y-2">
                <Label className="font-medium">
                  8. Weighbridge registration no. & Address of Weighbridge
                </Label>
                <Input
                  value={weighBridgeNo}
                  onChange={(e) => setWeighBridgeNo(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <div className="font-medium">{weighBridgeNo}</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t pt-4">
              <div className="space-y-2">
                <Label className="font-medium">
                  9. Verified gross mass of container (method-1/method-2)
                </Label>
                <Select
                  value={verifiedGrossMass}
                  onValueChange={setVerifiedGrossMass}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="method-1">method-1</SelectItem>
                    <SelectItem value="method-2">method-2</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <div className="font-medium">{verifiedGrossMass}</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t pt-4">
              <div className="space-y-2">
                <Label className="font-medium">
                  10. Unit of measure (KG / MT/ LBS)
                </Label>
                <Select value={unitOfMeasure} onValueChange={setUnitOfMeasure}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="KG">KG</SelectItem>
                    <SelectItem value="MT">MT</SelectItem>
                    <SelectItem value="LBS">LBS</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <div className="font-medium">{unitOfMeasure}</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t pt-4">
              <div className="space-y-2">
                <Label className="font-medium">
                  11. Date and time of weighing
                </Label>
                <div className="flex gap-2">
                  <Input
                    value={`Dt. ${weighingDate}`}
                    readOnly
                    className="bg-gray-50"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <div className="font-medium">Dt. {weighingDate}</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t pt-4">
              <div className="space-y-2">
                <Label className="font-medium">12. Weighing slip no.</Label>
                <Input
                  value={weighingSlipNo}
                  onChange={(e) => setWeighingSlipNo(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <div className="font-medium">{weighingSlipNo}</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t pt-4">
              <div className="space-y-2">
                <Label className="font-medium">
                  13. Type (Normal/Reefer/Hazardous/others)
                </Label>
                <Select value={containerType} onValueChange={setContainerType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="NORMAL">NORMAL</SelectItem>
                    <SelectItem value="REEFER">REEFER</SelectItem>
                    <SelectItem value="HAZARDOUS">HAZARDOUS</SelectItem>
                    <SelectItem value="OTHER">OTHER</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <div className="font-medium">{containerType}</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t pt-4">
              <div className="space-y-2">
                <Label className="font-medium">
                  14. If Hazardous UN NO.IMDG class
                </Label>
                <Input
                  value={hazardousClass}
                  onChange={(e) => setHazardousClass(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <div className="font-medium">{hazardousClass}</div>
              </div>
            </div>
          </div>

          {/* Signature Section */}
          <div className="grid grid-cols-2 gap-6 border-t pt-6">
            <div className="space-y-2">
              <div className="font-medium">
                Signature of authorised person of shipper
              </div>
              <div className="font-medium mt-4">NAME: {shipperOfficial}</div>
              <div className="font-medium">DATE: Dt. {weighingDate}</div>
            </div>
          </div>

          {/* VGM Table */}
          <div className="mt-6 border-t pt-6">
            <Table className="border w-full">
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="border font-medium text-center">
                    BOOKING NO
                  </TableHead>
                  <TableHead className="border font-medium text-center">
                    CONTAINER NUMBER
                  </TableHead>
                  <TableHead className="border font-medium text-center">
                    VGM (KGS)
                    <br />( CARGO+TARE WEIGHT)
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {containerInfo?.containerRows ? (
                  containerInfo.containerRows.map((row, index) => (
                    <TableRow key={index} className="border-b hover:bg-gray-50">
                      <TableCell className="border p-0">
                        <Input
                          value={bookingNumbers[index] || ""}
                          onChange={(e) =>
                            handleBookingNumberChange(index, e.target.value)
                          }
                          className="h-10 border-0 text-center"
                        />
                      </TableCell>
                      <TableCell className="border text-center">
                        {row.containerNo || "S***********"}
                      </TableCell>
                      <TableCell className="border">
                        <div className="flex items-center justify-center">
                          <div className="text-right pr-2 w-1/3">
                            {row.grossWeight || "0.00"}
                          </div>
                          <div className="px-2">+</div>
                          <Input
                            value={tareWeights[index] || ""}
                            onChange={(e) =>
                              handleTareWeightChange(index, e.target.value)
                            }
                            className="h-10 border-0 text-center w-20"
                          />
                          <div className="px-2">=</div>
                          <div className="text-right pl-2 w-1/3 font-medium">
                            {calculateTotalVGM(
                              row.grossWeight || "0",
                              tareWeights[index] || "0"
                            )}
                          </div>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow className="border-b hover:bg-gray-50">
                    <TableCell className="border p-0">
                      <Input
                        value="EI*********"
                        onChange={(e) => {}}
                        className="h-10 border-0 text-center"
                      />
                    </TableCell>
                    <TableCell className="border text-center">
                      S***********
                    </TableCell>
                    <TableCell className="border">
                      <div className="flex items-center justify-center">
                        <div className="text-right pr-2 w-1/3">111111.00</div>
                        <div className="px-2">+</div>
                        <Input
                          value="2180"
                          onChange={(e) => {}}
                          className="h-10 border-0 text-center w-20"
                        />
                        <div className="px-2">=</div>
                        <div className="text-right pl-2 w-1/3 font-medium">
                          113291.00
                        </div>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Footer Buttons */}
      <div className="flex justify-between mt-8">
        <Button variant="outline" onClick={onBack}>
          Back
        </Button>
        <Button
          onClick={() => {
            localStorage.setItem("taxDialogBox", "false");
            handleSubmit();
          }}
        >
          Submit
        </Button>
      </div>

      {/* Letterhead Bottom Image */}
      {letterheadBottomImage ? (
        <div className="w-full flex justify-center mt-6">
          <img 
            src={letterheadBottomImage} 
            alt="Letterhead Bottom" 
            className="w-full object-contain max-h-40"
          />
        </div>
      ) : selectedShipper ? (
        <Alert variant="destructive" className="mt-6">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Missing Letterhead</AlertTitle>
          <AlertDescription>
            Please add the letterhead bottom image for {selectedShipper.company_name} through the Admin panel.
          </AlertDescription>
        </Alert>
      ) : null}
    </div>
  );
};

export default VgmForm;
