// Import types but handle the case where axios might not be installed yet
import { Invoice, Client, Product, ShippingTerm } from './types';

// Create a simple fetch wrapper for API calls
// This avoids dependency on axios which might not be installed
const api = {
  async get(url: string) {
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token') || ''}`
        }
      });
      if (!response.ok) throw new Error(`API error: ${response.status}`);
      return await response.json();
    } catch (error) {
      console.error(`GET request failed: ${url}`, error);
      return null;
    }
  },
  
  async post(url: string, data: any) {
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token') || ''}`
        },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error(`API error: ${response.status}`);
      return await response.json();
    } catch (error) {
      console.error(`POST request failed: ${url}`, error);
      return null;
    }
  },
  
  async put(url: string, data: any) {
    try {
      const response = await fetch(url, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token') || ''}`
        },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error(`API error: ${response.status}`);
      return await response.json();
    } catch (error) {
      console.error(`PUT request failed: ${url}`, error);
      return null;
    }
  },
  
  async delete(url: string) {
    try {
      const response = await fetch(url, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token') || ''}`
        }
      });
      if (!response.ok) throw new Error(`API error: ${response.status}`);
      return await response.json();
    } catch (error) {
      console.error(`DELETE request failed: ${url}`, error);
      return null;
    }
  }
};

// Base API URL
const BASE_URL = 'http://localhost:8000/api';

// Helper function to build full URL
const buildUrl = (endpoint: string) => `${BASE_URL}${endpoint.startsWith('/') ? endpoint : '/' + endpoint}`;

// API endpoints for invoices
export const  invoiceApi = {
  getAll: async (): Promise<Invoice[]> => {
    try {
      const data = await api.get(buildUrl('/invoice'));
      console.log(data);
      
      return data.invoices || [];
    } catch (error) {
      console.error('Error fetching invoices:', error);
      return [];
    }
  },
  
  getById: async (id: string): Promise<Invoice | null> => {
    try {
      const data = await api.get(buildUrl(`/invoices/${id}`));
      return data;
    } catch (error) {
      console.error(`Error fetching invoice ${id}:`, error);
      return null;
    }
  },
  
  create: async (invoice: Omit<Invoice, 'id'>): Promise<Invoice | null> => {
    try {
      const data = await api.post(buildUrl('/invoices'), invoice);
      return data;
    } catch (error) {
      console.error('Error creating invoice:', error);
      return null;
    }
  },
  
  update: async (id: string, invoice: Partial<Invoice>): Promise<Invoice | null> => {
    try {
      const data = await api.put(buildUrl(`/invoices/${id}`), invoice);
      return data;
    } catch (error) {
      console.error(`Error updating invoice ${id}:`, error);
      return null;
    }
  },
  
  delete: async (id: string): Promise<boolean> => {
    try {
      await api.delete(buildUrl(`/invoices/${id}`));
      return true;
    } catch (error) {
      console.error(`Error deleting invoice ${id}:`, error);
      return false;
    }
  }
};

// API endpoints for exporters/clients
export const exporterApi = {
  getAll: async (): Promise<Client[]> => {
    try {
      const data = await api.get(buildUrl('/exporters'));
      return data || [];
    } catch (error) {
      console.error('Error fetching exporters:', error);
      return [];
    }
  },
  
  getById: async (id: string): Promise<Client | null> => {
    try {
      const data = await api.get(buildUrl(`/exporters/${id}`));
      return data;
    } catch (error) {
      console.error(`Error fetching exporter ${id}:`, error);
      return null;
    }
  },
  
  create: async (exporter: Omit<Client, 'id'>): Promise<Client | null> => {
    try {
      const data = await api.post(buildUrl('/exporters'), exporter);
      return data;
    } catch (error) {
      console.error('Error creating exporter:', error);
      return null;
    }
  },
  
  update: async (id: string, exporter: Partial<Client>): Promise<Client | null> => {
    try {
      const data = await api.put(buildUrl(`/exporters/${id}`), exporter);
      return data;
    } catch (error) {
      console.error(`Error updating exporter ${id}:`, error);
      return null;
    }
  },
  
  delete: async (id: string): Promise<boolean> => {
    try {
      await api.delete(buildUrl(`/exporters/${id}`));
      return true;
    } catch (error) {
      console.error(`Error deleting exporter ${id}:`, error);
      return false;
    }
  }
};

// API endpoints for products
export const productApi = {
  getAll: async (): Promise<Product[]> => {
    try {
      const data = await api.get(buildUrl('/products'));
      return data || [];
    } catch (error) {
      console.error('Error fetching products:', error);
      return [];
    }
  },
  
  getById: async (id: string): Promise<Product | null> => {
    try {
      const data = await api.get(buildUrl(`/products/${id}`));
      return data;
    } catch (error) {
      console.error(`Error fetching product ${id}:`, error);
      return null;
    }
  },
  
  create: async (product: Omit<Product, 'id'>): Promise<Product | null> => {
    try {
      const data = await api.post(buildUrl('/products'), product);
      return data;
    } catch (error) {
      console.error('Error creating product:', error);
      return null;
    }
  },
  
  update: async (id: string, product: Partial<Product>): Promise<Product | null> => {
    try {
      const data = await api.put(buildUrl(`/products/${id}`), product);
      return data;
    } catch (error) {
      console.error(`Error updating product ${id}:`, error);
      return null;
    }
  },
  
  delete: async (id: string): Promise<boolean> => {
    try {
      await api.delete(buildUrl(`/products/${id}`));
      return true;
    } catch (error) {
      console.error(`Error deleting product ${id}:`, error);
      return false;
    }
  }
};

// API endpoints for shipping terms
export const shippingTermApi = {
  getAll: async (): Promise<ShippingTerm[]> => {
    try {
      const data = await api.get(buildUrl('/shipping-terms'));
      return data || [];
    } catch (error) {
      console.error('Error fetching shipping terms:', error);
      return [];
    }
  },
  
  getById: async (id: string): Promise<ShippingTerm | null> => {
    try {
      const data = await api.get(buildUrl(`/shipping-terms/${id}`));
      return data;
    } catch (error) {
      console.error(`Error fetching shipping term ${id}:`, error);
      return null;
    }
  },
  
  create: async (term: Omit<ShippingTerm, 'id'>): Promise<ShippingTerm | null> => {
    try {
      const data = await api.post(buildUrl('/shipping-terms'), term);
      return data;
    } catch (error) {
      console.error('Error creating shipping term:', error);
      return null;
    }
  },
  
  update: async (id: string, term: Partial<ShippingTerm>): Promise<ShippingTerm | null> => {
    try {
      const data = await api.put(buildUrl(`/shipping-terms/${id}`), term);
      return data;
    } catch (error) {
      console.error(`Error updating shipping term ${id}:`, error);
      return null;
    }
  },
  
  delete: async (id: string): Promise<boolean> => {
    try {
      await api.delete(buildUrl(`/shipping-terms/${id}`));
      return true;
    } catch (error) {
      console.error(`Error deleting shipping term ${id}:`, error);
      return false;
    }
  }
};

// Dashboard statistics API
export const dashboardApi = {
  getStats: async () => {
    try {
      const data = await api.get(buildUrl('/invoice'));
      if (data) return data.counts;
      
      // If API fails, return default structure
      return {
        invoiceCount: 0,
        exporterCount: 0,
        productCount: 0,
        shippingTermCount: 0
      };
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      return {
        invoiceCount: 0,
        exporterCount: 0,
        productCount: 0,
        shippingTermCount: 0
      };
    }
  },
  
  getRecentInvoices: async (limit = 8) => {
    try {
      const data = await api.get(buildUrl(`/invoice?limit=${limit}`));
      return data.invoices || [];
    } catch (error) {
      console.error('Error fetching recent invoices:', error);
      return [];
    }
  }
};

export default api;
