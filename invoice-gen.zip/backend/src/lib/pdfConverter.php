<?php
require __DIR__.'/../../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

function convertExcelToPdfWithPrintArea($inputFilePath, $outputDir, $outputExcelName = 'output_with_printarea.xlsx')
{
    if (!file_exists($inputFilePath)) {
        echo "❌ Error: Input Excel file not found: {$inputFilePath}\n";
        return;
    }

    // Ensure output directory exists
    if (!is_dir($outputDir)) {
        mkdir($outputDir, 0777, true);
        echo "📁 Created output directory: {$outputDir}\n";
    }

    $outputExcelFile = rtrim($outputDir, '/\\') . DIRECTORY_SEPARATOR . $outputExcelName;

    // 1️⃣ Load the Excel file
    $spreadsheet = IOFactory::load($inputFilePath);

    // 2️⃣ Set print area for each sheet
    foreach ($spreadsheet->getAllSheets() as $sheet) {
        $title = $sheet->getTitle();
        $lastRow = $sheet->getHighestRow();
        $lastColumn = $sheet->getHighestColumn();
        echo "🔍 Sheet '{$title}': Last used row: {$lastRow}, Last used column: {$lastColumn}\n";

        if ($lastRow > 1 || $lastColumn !== 'A') {
            $printArea = "A1:{$lastColumn}{$lastRow}";
            $sheet->getPageSetup()->setPrintArea($printArea);
        } else {
            echo "⚠️ Skipping empty sheet: '{$title}'.\n";
        }
    }

    // 3️⃣ Save modified Excel file
    $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
    $writer->save($outputExcelFile);
    echo "✅ Excel file with print area saved as '{$outputExcelFile}'.\n";

    // 4️⃣ Convert Excel to PDF using LibreOffice
    $os = strtoupper(substr(PHP_OS, 0, 3));
    $inputPath = realpath($outputExcelFile);
    $outputPath = realpath($outputDir);
    
    if ($os === 'WIN') {
        $libreOffice = '"C:\\Program Files\\LibreOffice\\program\\soffice.exe"';
        $command = "$libreOffice --headless --convert-to pdf \"" . str_replace('\\', '/', $inputPath) . "\" --outdir \"" . str_replace('\\', '/', $outputPath) . "\" 2>&1";
    } else {
        $libreOffice = 'soffice';
        $command = "$libreOffice --headless --convert-to pdf " . escapeshellarg($inputPath) . " --outdir " . escapeshellarg($outputPath) . " 2>&1";
    }

    echo "🔄 Converting Excel to PDF...\n";
    exec($command, $output, $resultCode);

    if ($resultCode === 0) {
        echo "✅ Conversion complete! PDF saved in: '{$outputPath}'.\n";
        print_r($output);
    } else {
        echo "❌ Conversion failed. LibreOffice output:\n";
        print_r($output);
    }
}

// Usage:
$inputFile = __DIR__ . '/custom_invoice.xlsx';
$outputDir = __DIR__ . '/pdf';

convertExcelToPdfWithPrintArea($inputFile, $outputDir);
?>
