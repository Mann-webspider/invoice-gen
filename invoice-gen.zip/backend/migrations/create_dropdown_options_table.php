<?php

try {
    $pdo = new PDO('sqlite:' . __DIR__ . '/../database/database.sqlite');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $pdo->exec('DROP TABLE dropdown_options');
    // Create dropdown_options table
    $pdo->exec("CREATE TABLE IF NOT EXISTS dropdown_options (
        id TEXT PRIMARY KEY ,
        category VARCHAR(50) NOT NULL,
        value TEXT NOT NULL,
        is_active BOOLEAN DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at  DATETIME DEFAULT UPDATED_TIMESTAMP
    )");

    // Insert some sample data
    // $pdo->exec("INSERT INTO dropdown_options (category, value, label) VALUES 
    //     ('place_of_receipt', 'MORBI', 'MORBI'),
    //     ('place_of_receipt', 'DELHI', 'DELHI'),
    //     ('port_of_loading', 'MUNDRA', 'MUNDRA'),
    //     ('port_of_loading', 'NHAVA SHEVA', 'NHAVA SHEVA'),
    //     ('port_of_discharge', 'NEW YORK', 'NEW YORK'),
    //     ('port_of_discharge', 'LOS ANGELES', 'LOS ANGELES'),
    //     ('final_destination', 'USA', 'USA'),
    //     ('final_destination', 'CANADA', 'CANADA'),
    //     ('state_code', '27', 'Maharashtra'),
    //     ('state_code', '07', 'Delhi'),
    //     ('state_code', '24', 'Gujarat')
    // ");

    echo "Dropdown options table created and seeded successfully.\n";
} catch (PDOException $e) {
    echo "Error creating dropdown options table: " . $e->getMessage() . "\n";
    exit(1);
} 